from __future__ import print_function
from django.shortcuts import render
import sys
import ssl
import time
import datetime
import logging, traceback
import paho.mqtt.client as mqtt
from django.shortcuts import render
from django.http import HttpResponse
from .alpn_mqtt import *

topic = "test/date"
try:
    mqttc = mqtt.Client()
    ssl_context= ssl_alpn()
    mqttc.tls_set_context(context=ssl_context)
    logger.info("start connect")
    mqttc.connect(aws_iot_endpoint, port=443)
    logger.info("connect success")
    mqttc.loop_start()

    while True:
        now = datetime.datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        logger.info("try to publish:{}".format(now))
        mqttc.publish(topic, now)
        time.sleep(1)

except Exception as e:
    logger.error("exception main()")
    logger.error("e obj:{}".format(vars(e)))
    logger.error("message:{}".format(e.message))
    traceback.print_exc(file=sys.stdout)
